# netflix-clone
This is a Netflix clone developed using React, Node, Express, MongoDB, Java, PostgreSQL
